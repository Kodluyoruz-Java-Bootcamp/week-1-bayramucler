package h1_s9;

public class Main {
    public static void main(String[] args){
        MyList<String> a= new MyList<>();
        a.add("test");
        a.add("test2");
        a.add("test23");
        a.add("test2");
        a.add("test23");
        a.add("test23");
        a.add("test23");

        a.print();

    }
}
